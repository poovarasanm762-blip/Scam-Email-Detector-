"""
Scam Email Detection System
Internship Project — by Poovarasan

Flask backend. Serves index.html (templates/) and style.css / script.js
(static/), and provides the /scan and /sample API routes used by script.js.

HOW TO RUN:
    1. pip install flask
    2. python app.py
    3. Open http://127.0.0.1:5000 in your browser
"""

import re
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# ----------------------------------------------------------------------
# DETECTION ENGINE  (mirrors the rule set in the project report,
# Chapter 4: System Design)
# ----------------------------------------------------------------------

URGENCY = ["urgent", "immediately", "act now", "action required", "right away",
           "as soon as possible", "without delay", "final notice", "last chance",
           "expires today", "expires in 24 hours"]

THREAT = ["account will be suspended", "account has been suspended",
          "account will be closed", "account will be locked", "legal action",
          "suspended permanently", "unauthorized access detected",
          "unusual activity detected", "your account is at risk"]

PRIZE = ["you have won", "you've won", "congratulations you", "claim your prize",
         "lottery", "free gift", "selected as a winner", "cash reward",
         "you are a winner", "claim now"]

CREDENTIAL = ["verify your account", "verify your password", "enter your password",
              "bank account number", "credit card number", "social security number",
              "ssn", "otp", "one time password", "pin number",
              "confirm your identity", "update your billing"]

LINKY = ["click here", "click below", "click this link",
         "download attachment now", "open the attachment"]

GENERIC_GREETING = ["dear customer", "dear user", "dear valued customer",
                     "dear account holder", "dear sir/madam", "dear winner"]

SHORTENERS = ["bit.ly", "tinyurl", "t.co", "goo.gl", "is.gd", "ow.ly", "cutt.ly"]

FREE_DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "rediffmail.com"]

BRAND_WORDS = ["paypal", "bank", "amazon", "microsoft", "apple", "google", "irs",
               "netflix", "facebook", "instagram", "icici", "hdfc", "sbi", "axis"]

RAW_IP_LINK = re.compile(r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")
RAW_URL = re.compile(r"https?://\S+", re.IGNORECASE)


def contains_any(text, words):
    t = text.lower()
    return [w for w in words if w in t]


def lookalike_domain(domain):
    d = domain.lower()
    for b in BRAND_WORDS:
        if b in d and not d.startswith(b + ".") and d != b + ".com":
            return b
    return None


def scan_email(sender, subject, body):
    full_text = f"{subject}\n{body}".lower()
    score = 0
    signals = []

    # 1. Urgency language
    hits = contains_any(full_text, URGENCY)
    if hits:
        score += 2
        signals.append({"level": "mid", "title": "Urgency language detected",
                         "detail": f'Found pressure phrases such as "{hits[0]}". '
                                   f'Scammers use urgency to stop you thinking clearly.'})
    else:
        signals.append({"level": "clear", "title": "No urgency language",
                         "detail": "The message does not push you to act with unusual speed."})

    # 2. Threats
    hits = contains_any(full_text, THREAT)
    if hits:
        score += 3
        signals.append({"level": "high", "title": "Threat of account action",
                         "detail": f'Found a threat such as "{hits[0]}". Real organisations '
                                   f'rarely threaten account closure by email.'})
    else:
        signals.append({"level": "clear", "title": "No threats found",
                         "detail": "No mention of account suspension, closure or legal action."})

    # 3. Prize / reward lure
    hits = contains_any(full_text, PRIZE)
    if hits:
        score += 3
        signals.append({"level": "high", "title": "Unexpected prize or reward",
                         "detail": f'Found a phrase such as "{hits[0]}". Unsolicited prizes '
                                   f'are a classic scam lure.'})
    else:
        signals.append({"level": "clear", "title": "No prize claims",
                         "detail": "No mention of lotteries, prizes or unexpected rewards."})

    # 4. Sensitive information requests
    hits = contains_any(full_text, CREDENTIAL)
    if hits:
        score += 3
        signals.append({"level": "high", "title": "Requests sensitive information",
                         "detail": f'Asks for something like "{hits[0]}". Legitimate services '
                                   f'do not request passwords or OTPs by email.'})
    else:
        signals.append({"level": "clear", "title": "No sensitive info requested",
                         "detail": "The message does not ask for passwords, OTPs or card details."})

    # 5. Suspicious links
    linky_hits = contains_any(full_text, LINKY)
    urls = RAW_URL.findall(full_text)
    short_hit = next((u for u in urls if any(s in u for s in SHORTENERS)), None)
    ip_hit = bool(RAW_IP_LINK.search(full_text))
    if linky_hits or short_hit or ip_hit:
        score += 2
        detail = 'Contains a generic "click here" style call-to-action.'
        if short_hit:
            detail = f'Uses a shortened link ({short_hit}) which hides the real destination.'
        if ip_hit:
            detail = 'Links to a raw IP address instead of a normal website name — a strong phishing signal.'
        signals.append({"level": "high" if ip_hit else "mid",
                         "title": "Suspicious link pattern", "detail": detail})
    else:
        signals.append({"level": "clear", "title": "No suspicious links",
                         "detail": "No shortened, IP-based, or generic \"click here\" links found."})

    # 6. Generic greeting
    hits = contains_any(full_text, GENERIC_GREETING)
    if hits:
        score += 1
        signals.append({"level": "mid", "title": "Generic greeting",
                         "detail": f'Opens with "{hits[0]}" instead of a personal name — '
                                   f'common in mass-sent scam emails.'})
    else:
        signals.append({"level": "clear", "title": "No generic greeting",
                         "detail": "Does not open with a generic \"Dear Customer\" style greeting."})

    # 7. Sender domain check
    if sender:
        match = re.search(r"@([\w.-]+)", sender)
        domain = match.group(1) if match else sender
        look = lookalike_domain(domain)
        is_free = domain.lower() in FREE_DOMAINS
        if look:
            score += 3
            signals.append({"level": "high", "title": "Sender domain looks fake",
                             "detail": f'"{domain}" resembles the brand "{look}" but is not '
                                       f'its real domain — a common impersonation trick.'})
        elif is_free and any(b in subject.lower() for b in BRAND_WORDS):
            score += 2
            signals.append({"level": "mid", "title": "Free email domain for a brand message",
                             "detail": f'Sent from a free provider ({domain}) while claiming to '
                                       f'represent a company — official mail rarely comes from '
                                       f'free addresses.'})
        else:
            signals.append({"level": "clear", "title": "Sender domain looks normal",
                             "detail": f'No obvious brand impersonation detected in "{domain}".'})

    score = min(score, 10)

    if score <= 2:
        verdict_class, verdict_label = "safe", "Looks Genuine"
        verdict_sub = ("Few or no scam signals found. Still, always verify unexpected "
                        "requests directly with the sender.")
    elif score <= 5:
        verdict_class, verdict_label = "warn", "Suspicious — be careful"
        verdict_sub = ("Some warning signs found. Avoid clicking links or replying with "
                        "personal details until you confirm this is real.")
    else:
        verdict_class, verdict_label = "danger", "Likely a Scam"
        verdict_sub = ("Multiple strong scam signals found. Do not click any links, reply, "
                        "or share information. Delete or report this email.")

    return {
        "score": score,
        "verdict_class": verdict_class,
        "verdict_label": verdict_label,
        "verdict_sub": verdict_sub,
        "signals": signals,
    }


# ----------------------------------------------------------------------
# SAMPLE EMAILS (used by the "Try a scam/genuine example" buttons)
# ----------------------------------------------------------------------

SAMPLES = {
    "scam": {
        "sender": "security@paypa1-alerts.com",
        "subject": "URGENT: Your account will be suspended immediately",
        "body": ("Dear Customer,\n\nWe detected unusual activity on your account. "
                  "Your account will be suspended within 24 hours unless you verify "
                  "your account now.\n\nClick here to confirm your password and bank "
                  "account number: http://192.168.44.12/verify\n\nCongratulations, you "
                  "have also been selected for a free gift as a valued winner. Claim now "
                  "before it expires.\n\nAct immediately to avoid permanent account closure."),
    },
    "safe": {
        "sender": "noreply@github.com",
        "subject": "Your weekly repository activity summary",
        "body": ("Hi Poovarasan,\n\nHere is a summary of activity across your repositories "
                  "this week. You had 3 pull requests merged and 2 new issues opened.\n\n"
                  "View the full summary in your dashboard whenever it's convenient. "
                  "No action is required.\n\nThanks,\nThe GitHub Team"),
    },
}

# ----------------------------------------------------------------------
# ROUTES
# ----------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/scan", methods=["POST"])
def scan():
    data = request.get_json(force=True) or {}
    result = scan_email(
        sender=data.get("sender", ""),
        subject=data.get("subject", ""),
        body=data.get("body", ""),
    )
    return jsonify(result)


@app.route("/sample/<kind>")
def sample(kind):
    return jsonify(SAMPLES.get(kind, SAMPLES["safe"]))


if __name__ == "__main__":
    app.run(debug=True)
