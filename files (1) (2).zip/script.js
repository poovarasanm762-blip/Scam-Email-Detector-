async function scanEmail() {
  const sender = document.getElementById('sender').value.trim();
  const subject = document.getElementById('subject').value.trim();
  const body = document.getElementById('body').value.trim();

  const res = await fetch('/scan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sender, subject, body }),
  });
  const data = await res.json();

  const verdictBox = document.getElementById('verdictBox');
  verdictBox.className = 'verdict ' + data.verdict_class;
  document.getElementById('verdictLabel').textContent = data.verdict_label;
  document.getElementById('verdictSub').textContent = data.verdict_sub;
  document.getElementById('scoreNum').textContent = data.score + ' / 10';

  const signalsHtml = data.signals.map(s => {
    const cls = s.level === 'clear' ? 'clear' : (s.level === 'high' ? 'hit high' : 'hit');
    const icon = s.level === 'clear' ? '[ OK ]' : (s.level === 'high' ? '[ !! ]' : '[ ! ]');
    return `<div class="signal ${cls}">
              <div class="signal-icon">${icon}</div>
              <div class="signal-body"><b>${s.title}</b><p>${s.detail}</p></div>
            </div>`;
  }).join('');

  document.getElementById('signals').innerHTML = signalsHtml;
  document.getElementById('result').style.display = 'block';
  document.getElementById('result').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

async function loadSample(kind) {
  const res = await fetch('/sample/' + kind);
  const data = await res.json();
  document.getElementById('sender').value = data.sender;
  document.getElementById('subject').value = data.subject;
  document.getElementById('body').value = data.body;
}

function clearForm() {
  document.getElementById('sender').value = '';
  document.getElementById('subject').value = '';
  document.getElementById('body').value = '';
  document.getElementById('result').style.display = 'none';
}
